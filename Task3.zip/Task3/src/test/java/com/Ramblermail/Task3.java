package com.Ramblermail;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.edge.EdgeDriver;

import java.net.URL;

public class Task3 {

    public EdgeDriver driver;

    @Before
    public void setUp() {
        ClassLoader loader = ClassLoader.getSystemClassLoader();
        URL path = loader.getResource("MicrosoftWebDriver.exe");
        System.setProperty("webdriver.edge.driver",path.getPath());
        driver = new EdgeDriver();

        driver.get("https://mail.rambler.ru/?utm_source=head&utm_campaign=self_promo&utm_medium=topline&utm_content=mail");



    }

    @Test
    public void Task3(){
        driver.findElementByCssSelector("[id=login]").sendKeys("Emailtest55@rambler.ru");
        driver.findElementByCssSelector("[id=password").sendKeys("Parol66666");
        driver.findElementByCssSelector("input[type=\"submit\"]").click();
        System.out.println("ActualTitle is+"); //как вариант количество входящих писем можно получить из заголовка страницы входящей почты






    }





}
